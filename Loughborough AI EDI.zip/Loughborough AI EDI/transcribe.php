<?php
header('Content-Type: application/json');

// Simulated placeholder transcript
echo json_encode([
  'transcript' => 'This is a sample caption of what was said in the audio.'
]);